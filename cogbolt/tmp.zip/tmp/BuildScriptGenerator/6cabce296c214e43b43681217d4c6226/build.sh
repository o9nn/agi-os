#!/bin/bash
set -e

TOTAL_EXECUTION_START_TIME=$SECONDS
SOURCE_DIR="$1"
DESTINATION_DIR="$2"
INTERMEDIATE_DIR="$3"

if [ -f /opt/oryx/logger ]; then
	source /opt/oryx/logger
fi

if [ ! -d "$SOURCE_DIR" ]; then
    echo "Source directory '$SOURCE_DIR' does not exist." 1>&2
    exit 1
fi


cd "$SOURCE_DIR"
SOURCE_DIR=$(pwd -P)

if [ -z "$DESTINATION_DIR" ]
then
    DESTINATION_DIR="$SOURCE_DIR"
fi

if [ -d "$DESTINATION_DIR" ]
then
    cd "$DESTINATION_DIR"
    DESTINATION_DIR=$(pwd -P)
fi



if [ ! -z "$INTERMEDIATE_DIR" ]
then
	echo "Using intermediate directory '$INTERMEDIATE_DIR'."
	if [ ! -d "$INTERMEDIATE_DIR" ]
	then
		echo
		echo "Intermediate directory doesn't exist, creating it...'"
		mkdir -p "$INTERMEDIATE_DIR"		
	fi

	cd "$INTERMEDIATE_DIR"
	INTERMEDIATE_DIR=$(pwd -P)
	cd "$SOURCE_DIR"
	echo
	echo "Copying files to the intermediate directory..."
	START_TIME=$SECONDS
	excludedDirectories=""
	
		excludedDirectories+=" --exclude __oryx_packages__"
		
		excludedDirectories+=" --exclude .git"
		

	
	rsync -rcE --delete $excludedDirectories . "$INTERMEDIATE_DIR"

	ELAPSED_TIME=$(($SECONDS - $START_TIME))
	echo "Done in $ELAPSED_TIME sec(s)."
	SOURCE_DIR="$INTERMEDIATE_DIR"
fi

echo
echo "Source directory     : $SOURCE_DIR"
echo "Destination directory: $DESTINATION_DIR"
echo



cd "$SOURCE_DIR"


if [ -f /opt/oryx/benv ]; then
	source /opt/oryx/benv python=3.12.1 dynamic_install_root_dir="/opt"
fi





export SOURCE_DIR
export DESTINATION_DIR


mkdir -p "$DESTINATION_DIR"





cd "$SOURCE_DIR"
set -e
# TODO: refactor redundant code. Work-item: 1476457

declare -r TS_FMT='[%T%z] '
declare -r REQS_NOT_FOUND_MSG='Could not find setup.py or requirements.txt; Not running pip install. More information: https://aka.ms/requirements-not-found'
echo "Python Version: $python"
PIP_CACHE_DIR=/usr/local/share/pip-cache


COMMAND_MANIFEST_FILE="/workspaces/.oryx/oryx-build-commands.txt"


echo "Creating directory for command manifest file if it does not exist"
mkdir -p "$(dirname "$COMMAND_MANIFEST_FILE")"
echo "Removing existing manifest file"
rm -f "$COMMAND_MANIFEST_FILE"

echo "PlatformWithVersion=Python 3.12.1" > "$COMMAND_MANIFEST_FILE"

InstallCommand=""

if [ ! -d "$PIP_CACHE_DIR" ];then
    mkdir -p $PIP_CACHE_DIR
fi


    REQUIREMENTS_TXT_FILE="requirements.txt"



    moreInformation="More information: https://aka.ms/troubleshoot-python"
    if [ -e "$REQUIREMENTS_TXT_FILE" ]
    then
        set +e
        echo
        echo Running pip install...
        START_TIME=$SECONDS
        InstallCommand="$python -m pip install --cache-dir $PIP_CACHE_DIR --prefer-binary -r $REQUIREMENTS_TXT_FILE --target="/home/codespace/.local/lib/python3.12/site-packages" --upgrade | ts $TS_FMT"
        printf %s " , $InstallCommand" >> "$COMMAND_MANIFEST_FILE"
        output=$( ( $python -m pip install --cache-dir $PIP_CACHE_DIR --prefer-binary -r $REQUIREMENTS_TXT_FILE --target="/home/codespace/.local/lib/python3.12/site-packages" --upgrade | ts $TS_FMT; exit ${PIPESTATUS[0]} ) 2>&1; exit ${PIPESTATUS[0]} )
        pipInstallExitCode=${PIPESTATUS[0]}

        ELAPSED_TIME=$(($SECONDS - $START_TIME))
        echo "Done in $ELAPSED_TIME sec(s)."
        set -e
        echo "${output}"
        if [[ $pipInstallExitCode != 0 ]]
        then
            LogError "${output} | Exit code: ${pipInstallExitCode} | Please review your requirements.txt | ${moreInformation}"
            exit $pipInstallExitCode
        fi
    elif [ -e "setup.py" ]
    then
        echo
        START_TIME=$SECONDS
        UpgradeCommand="pip install --upgrade pip"
        printf %s " , $UpgradeCommand" >> "$COMMAND_MANIFEST_FILE"
        pip install --upgrade pip
        ELAPSED_TIME=$(($SECONDS - $START_TIME))
        echo "Done in $ELAPSED_TIME sec(s)."

        set +e
        echo "Running python setup.py install..."
        InstallCommand="$python setup.py install --user| ts $TS_FMT"
        printf %s " , $InstallCommand" >> "$COMMAND_MANIFEST_FILE"
        output=$( ( $python setup.py install --user| ts $TS_FMT; exit ${PIPESTATUS[0]} ) 2>&1; exit ${PIPESTATUS[0]} )
        pythonBuildExitCode=${PIPESTATUS[0]}
        set -e
        echo "${output}"
        if [[ $pythonBuildExitCode != 0 ]]
        then
            LogError "${output} | Exit code: ${pipInstallExitCode} | Please review your setup.py | ${moreInformation}"
            exit $pythonBuildExitCode
        fi
    elif [ -e "pyproject.toml" ]
    then
        set +e
        echo "Running pip install poetry..."
        InstallPipCommand="pip install poetry"
        printf %s " , $InstallPipCommand" >> "$COMMAND_MANIFEST_FILE"
        pip install poetry
        START_TIME=$SECONDS
        echo "Running poetry install..."
        InstallPoetryCommand="poetry install --no-dev"
        printf %s " , $InstallPoetryCommand" >> "$COMMAND_MANIFEST_FILE"
        output=$( ( poetry install --no-dev; exit ${PIPESTATUS[0]} ) 2>&1 )
        pythonBuildExitCode=${PIPESTATUS[0]}
        ELAPSED_TIME=$(($SECONDS - $START_TIME))
        echo "Done in $ELAPSED_TIME sec(s)."
        set -e
        echo "${output}"
        if [[ $pythonBuildExitCode != 0 ]]
        then
            LogWarning "${output} | Exit code: {pythonBuildExitCode} | Please review message | ${moreInformation}"
            exit $pythonBuildExitCode
        fi
    else
        echo $REQS_NOT_FOUND_MSG
    fi

    # We need to use the python binary selected by benv
    python_bin=$python

    # Detect the location of the site-packages to add the .pth file
    # For the local site package, only major and minor versions are provided, so we fetch it again
    SITE_PACKAGE_PYTHON_VERSION=$($python -c "import sys; print(str(sys.version_info.major) + '.' + str(sys.version_info.minor))")
    SITE_PACKAGES_PATH=$PIP_CACHE_DIR"/lib/python"$SITE_PACKAGE_PYTHON_VERSION"/site-packages"
    mkdir -p $SITE_PACKAGES_PATH
    # To make sure the packages are available later, e.g. for collect static or post-build hooks, we add a .pth pointing to them
    APP_PACKAGES_PATH=$(pwd)"//home/codespace/.local/lib/python3.12/site-packages"
    echo $APP_PACKAGES_PATH > $SITE_PACKAGES_PATH"/oryx.pth"






    set +e
    if [ -e "$SOURCE_DIR/manage.py" ]
    then
        if grep -iq "Django" "$SOURCE_DIR/$REQUIREMENTS_TXT_FILE"
        then
            echo
            echo Content in source directory is a Django app
            echo Running 'collectstatic'...
            START_TIME=$SECONDS
            CollectStaticCommand="$python_bin manage.py collectstatic --noinput"
            printf %s " , $CollectStaticCommand" >> "$COMMAND_MANIFEST_FILE"
            output=$(($python_bin manage.py collectstatic --noinput; exit ${PIPESTATUS[0]}) 2>&1)
            EXIT_CODE=${PIPESTATUS[0]}
            echo "${output}"
            if [[ $EXIT_CODE != 0 ]]
            then
                recommendation="Please review message"
                LogWarning "${output} | Exit code: ${EXIT_CODE} | ${recommendation} | ${moreInformation}"
            fi
            ELAPSED_TIME=$(($SECONDS - $START_TIME))
            echo "Done in $ELAPSED_TIME sec(s)."
        else
            output="Missing Django module in $SOURCE_DIR/$REQUIREMENTS_TXT_FILE"
            recommendation="Add Django to your requirements.txt file."
            LogWarning "${output} | Exit code: 0 | ${recommendation} | ${moreInformation}"
        fi
    fi
    set -e



ReadImageType=$(cat /opt/oryx/.imagetype)

if [ "$ReadImageType" = "vso-focal" ] || [ "$ReadImageType" = "vso-debian-bullseye" ]
then
    echo $ReadImageType
    cat "$COMMAND_MANIFEST_FILE"
else
    echo "Not a vso image, so not writing build commands"
    rm "$COMMAND_MANIFEST_FILE"
fi







if [ "$SOURCE_DIR" != "$DESTINATION_DIR" ]
then
	echo "Preparing output..."

	
	

		
			cd "$SOURCE_DIR"
	
			echo
			echo "Copying files to destination directory '$DESTINATION_DIR'..."
			START_TIME=$SECONDS
			excludedDirectories=""
			
				excludedDirectories+=" --exclude .git"
				
	
			
	
			
			rsync -rcE --links $excludedDirectories . "$DESTINATION_DIR"
	
			
	
			ELAPSED_TIME=$(($SECONDS - $START_TIME))
			echo "Done in $ELAPSED_TIME sec(s)."
		

	
fi


MANIFEST_FILE=oryx-manifest.toml

MANIFEST_DIR=/workspaces/.oryx
if [ -z "$MANIFEST_DIR" ];then
	MANIFEST_DIR="$DESTINATION_DIR"
fi
mkdir -p "$MANIFEST_DIR"

echo
echo "Removing existing manifest file"
rm -f "$MANIFEST_DIR/$MANIFEST_FILE"

echo "Creating a manifest file..."

echo "PythonVersion=\"3.12.1\"" >> "$MANIFEST_DIR/$MANIFEST_FILE"

echo "pythonBuildCommandsFile=\"/workspaces/.oryx/oryx-build-commands.txt\"" >> "$MANIFEST_DIR/$MANIFEST_FILE"

echo "packagedir=\"/home/codespace/.local/lib/python3.12/site-packages\"" >> "$MANIFEST_DIR/$MANIFEST_FILE"

echo "OperationId=\"12ab7cd2e7b8119e\"" >> "$MANIFEST_DIR/$MANIFEST_FILE"

echo "SourceDirectoryInBuildContainer=\"/workspaces/bolt-cppml\"" >> "$MANIFEST_DIR/$MANIFEST_FILE"

echo "PlatformName=\"python\"" >> "$MANIFEST_DIR/$MANIFEST_FILE"

echo "CompressDestinationDir=\"false\"" >> "$MANIFEST_DIR/$MANIFEST_FILE"

echo "Manifest file created."



OS_TYPE_SOURCE_DIR="/opt/oryx/.ostype"
if [ -f "$OS_TYPE_SOURCE_DIR" ]
then
	echo "Copying .ostype to manifest output directory."
	cp "$OS_TYPE_SOURCE_DIR" "$MANIFEST_DIR/.ostype"
else
	echo "File $OS_TYPE_SOURCE_DIR does not exist. Cannot copy to manifest directory." 1>&2
	exit 1
fi

TOTAL_EXECUTION_ELAPSED_TIME=$(($SECONDS - $TOTAL_EXECUTION_START_TIME))
echo
echo "Done in $TOTAL_EXECUTION_ELAPSED_TIME sec(s)."